package securityService;

import ImageService.ImageService;
import application.StatusListener;
import data.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {

    private SecurityService securityService;
    private Sensor sensor;
    private final String random = UUID.randomUUID().toString();

    @Mock
    private SecurityRepository securityRepository;

    @Mock
    private StatusListener statusListener;

    @Mock
    private ImageService imageService;

    private Sensor createNewSensor() {
        return new Sensor(random, SensorType.DOOR);
    }

    private Set<Sensor> getAllSensors(int count, boolean status) {
        Set<Sensor> sensors = new HashSet<>();
        for (int i = 0; i  < count; i++) {
            sensors.add(new Sensor(random, SensorType.DOOR));
        }
        sensors.forEach(sensor -> sensor.setActive(status));

        return sensors;
    }

    @BeforeEach
    void init() {
        securityService = new SecurityService(securityRepository, imageService);
        sensor = createNewSensor();
    }

    // TEST # 1
    @Test
    void ifAlarmIsArmedAndSensorIsActivated_SetAlarmStatusToPending() {
        when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }

    // TEST # 2
    @Test
    void ifAlarmIsArmedAndSensorIsActivatedAndPending_SetAlarmStatusToAlarm() {
        when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    // TEST # 3
    @Test
    void ifPendingAlarmAndSensorIsInactive_SetAlarmStatusToNoAlarm() {
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        sensor.setActive(false);
        securityService.changeSensorActivationStatus(sensor);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }


    // TEST # 4
    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    void ifAlarmIsActivate_ChangingSensorState_ShouldNotAffectAlarmStatus(boolean status) {
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        securityService.changeSensorActivationStatus(sensor, status);
        verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
    }

    // TEST # 5
    @Test
    void ifAlarmStatusIsPendingAndSensorIsActivated_SetAlarmStatusToAlarm() {
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        sensor.setActive(true);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    // TEST # 6
    @ParameterizedTest
    @EnumSource(value = AlarmStatus.class, names =  {"NO_ALARM", "PENDING_ALARM", "ALARM"})
    void ifSensorIsDeactivatedWhileInactive_NoChangesToAlarmStatus(AlarmStatus status) {
        when(securityRepository.getAlarmStatus()).thenReturn(status);
        sensor.setActive(false);
        securityService.changeSensorActivationStatus(sensor, false);
        verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
    }

    // TEST # 7
    @Test
    void ifImageServiceIdentifiesCatWhileAlarmArmedHome_SetAlarmStatusToAlarm() {
        BufferedImage catImage = new BufferedImage(300, 256, BufferedImage.TYPE_INT_RGB);
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(imageService.imageContainsCat(any(), ArgumentMatchers.anyFloat())).thenReturn(true);
        securityService.processImage(catImage);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    // TEST # 8
    @Test
    void ifImageServiceIdentifiesNoCatImage_SetAlarmStatusToNoAlarmAsLongAsSensorIsNotActive() {
        Set<Sensor> sensors = getAllSensors(3, false);
        when(securityRepository.getSensors()).thenReturn(sensors);
        when(imageService.imageContainsCat(any(), ArgumentMatchers.anyFloat())).thenReturn(false);
        securityService.processImage(mock(BufferedImage.class));
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // TEST # 9
    @Test
    void ifSystemIsDisarmed_SetNoAlarmStatus() {
        securityService.setArmingStatus(ArmingStatus.DISARMED);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // TEST # 10
    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names =  {"ARMED_HOME", "ARMED_AWAY"})
    void ifSystemIsArmed_ResetTheSensorsToInactiveState(ArmingStatus status) {
        Set<Sensor> sensors = getAllSensors(4, true);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        when(securityRepository.getSensors()).thenReturn(sensors);
        securityService.setArmingStatus(status);
        securityRepository.getSensors().forEach(sensor ->{
            assertFalse(sensor.getActive());
        });
    }

    // TEST # 11
    @Test
    void ifSystemIsArmedHomeWhileCameraShowsCat_SetAlarmStatusToAlarm() {
        BufferedImage ImageOfCat = new BufferedImage(300, 256, BufferedImage.TYPE_INT_RGB);
        when(imageService.imageContainsCat(any(),anyFloat())).thenReturn(true);
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.DISARMED);
        securityService.processImage(ImageOfCat);
        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }
}
